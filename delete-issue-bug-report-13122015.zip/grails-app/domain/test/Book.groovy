package test

class Book {

    String title

    static constraints = {
        title nullable: false
    }
}
